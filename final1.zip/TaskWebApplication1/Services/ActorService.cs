﻿using FluentValidation;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TaskWebApplication1.Data;
using TaskWebApplication1.Model;
using TaskWebApplication1.ViewModel;

namespace TaskWebApplication1.Services
{
    public class ActorService : IActorService
    {
        private readonly ApiDbContext _ApiDbContext;
        private readonly IValidator<AddActorCommand> _validator;

        public ActorService(ApiDbContext context)
        {
            _ApiDbContext = context;
        }
      

        public async Task<ActorResult> AddActor(AddActorCommand command)
        {
            var actor = new Actor()
            {
                Name = command.Name,
                Sex = command.Sex,
                DOB = command.DOB,
                Bio = command.Bio
            };

            var response = (await _ApiDbContext.Actors.AddAsync(actor)).Entity;

            await _ApiDbContext.SaveChangesAsync();

            if (response != null)
            {
                ActorResult actorResult = new ActorResult()
                {
                    Aid = response.Aid,
                    Name = command.Name,
                    Sex = command.Sex,
                    DOB = command.DOB,
                    Bio = command.Bio
                };
                return actorResult;
            }
            return null;
        }

        public async Task<List<Actor>> GetAllActorsAsync()
        {
            return await _ApiDbContext.Actors.ToListAsync();
        }


        public async Task<ActorResult> GetActorByIdAsync(int id)
        {
            var response = await _ApiDbContext.Actors.FirstOrDefaultAsync(a => a.Aid == id);
            if (response == null)
            {
                throw new Exception($"Actor with ID {id} not found.");
            }
            ActorResult actorResult = new ActorResult()
            {
                Aid = response.Aid,
                Name = response.Name,
                Sex = response.Sex,
                Bio = response.Bio,
                DOB = response.DOB
            };
            return actorResult;
        }


        public async Task DeleteActor(int id)
        {
            var actor = await _ApiDbContext.Actors.FirstOrDefaultAsync(a => a.Aid == id);
            if (actor == null)
            {
                throw new Exception($"Actor with ID {id} not found.");

            }
            _ApiDbContext.Actors.Remove(actor);
            await _ApiDbContext.SaveChangesAsync();
        }


        public async Task<Actor> UpdateActor(int id, UpdateActorCommand actor)
        {
            var act = await _ApiDbContext.Actors.FirstOrDefaultAsync(a => a.Aid == id);
            if (act == null)
            {
                throw new Exception($"Actor with ID {id} not found.");
            }

            act.Name = actor.Name;
            act.Sex = actor.Sex;
            act.DOB = actor.DOB;
            act.Bio = actor.Bio;

            _ApiDbContext.Actors.Update(act);
            await _ApiDbContext.SaveChangesAsync();

            return act;
        }

    }
}

