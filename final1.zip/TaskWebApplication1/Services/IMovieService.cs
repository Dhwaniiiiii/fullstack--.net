﻿using TaskWebApplication1.Model;
using TaskWebApplication1.ViewModel;

namespace TaskWebApplication1.Services
{
    public interface IMovieService
    {
        Task<MovieResult> AddMovie(AddMovieCommand command);
        Task<IEnumerable<MovieResult>> GetAllMovies();
        Task<MovieResult> GetIdMovies(int id);
        Task DeleteMovie(int id);
        Task<UpdateMovieResult> UpdateMovie(int id, UpdateMovieCommand command);


    }
}
