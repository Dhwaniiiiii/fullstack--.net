﻿using System.ComponentModel.DataAnnotations;
using Microsoft.EntityFrameworkCore;
using TaskWebApplication1.Data;
using TaskWebApplication1.Model;
using TaskWebApplication1.ViewModel;

namespace TaskWebApplication1.Services
{ 
    public class ProducerService : IProducerService
    {
        private readonly ApiDbContext _ApiDbContext;

        public ProducerService(ApiDbContext context)
        {
            _ApiDbContext = context;
        }

        public async Task<ProducerResult> AddProducer(AddProducerCommand command)
        {

            //if (string.IsNullOrWhiteSpace(command.Name))
            //{
            //    throw new ArgumentException("Name is required.");
            //}

            //if (string.IsNullOrWhiteSpace(command.Sex))
            //{
            //    throw new ArgumentException("Sex is required.");
            //}

            //if (string.IsNullOrWhiteSpace(command.DOB))
            //{
            //    throw new ArgumentException("Date of Birth (DOB) is required.");
            //}

            //// Validate Sex value: It must be "male", "female", or "other"
            //var validSexValues = new[] { "male", "female", "other" };
            //if (!validSexValues.Contains(command.Sex.ToLower()))
            //{
            //    throw new ArgumentException("Sex must be one of the following: 'male', 'female', or 'other'.");
            //}

            //// Validate DOB: Check if the DOB is a valid date format
            //if (!DateTime.TryParse(command.DOB, out DateTime dob))
            //{
            //    throw new ArgumentException("Date of Birth (DOB) must be a valid date.");
            //}

            //// Bio length validation (optional)
            //if (command.Bio != null && command.Bio.Length > 500)
            //{
            //    throw new ArgumentException("Bio cannot exceed 500 characters.");
            //}


            var prod = new Producer()
            {
                Name = command.Name,
                Sex = command.Sex,
                DOB = command.DOB,
                Bio = command.Bio
            };

            var response = (await _ApiDbContext.Producers.AddAsync(prod)).Entity;

            await _ApiDbContext.SaveChangesAsync();

            if (response != null)
            {
                ProducerResult producerResult = new ProducerResult()
                {
                    Pid = response.Pid,
                    Name = command.Name,
                    Sex = command.Sex,
                    DOB = command.DOB,
                    Bio = command.Bio
                };

                return producerResult;
            }

            return null;
        }

        public async Task<List<Producer>> GetAllProducersAsync()
        {
            return await _ApiDbContext.Producers.ToListAsync();
        }


        public async Task<Producer> GetProducerByIdAsync(int id)
        {
            if (id <= 0)
            {
                throw new ArgumentException("Invalid producer ID.");
            }
            var pro = await _ApiDbContext.Producers
                .Where(p => p.Pid == id)
                .FirstOrDefaultAsync();

            if (pro == null)
            {
                throw new Exception($"Producer with ID {id} not found.");
            }
            return pro;
        }


        public async Task DeleteProducer(int id)
        {
            var prod = await _ApiDbContext.Producers.FirstOrDefaultAsync(p => p.Pid == id);
            if (prod == null)
            {
                throw new Exception($"Actor with ID {id} not found.");

            }
            _ApiDbContext.Producers.Remove(prod);
            await _ApiDbContext.SaveChangesAsync();
        }


        public async Task<Producer> UpdateProducer(int id, UpdateProducerCommand command)
        {
            //if (id <= 0)
            //{
            //    throw new ArgumentException("Invalid producer ID.");
            //}

            //if (command == null)
            //{
            //    throw new ArgumentNullException(nameof(command), "Producer data cannot be null.");
            //}

            //// Validate required fields
            //if (string.IsNullOrEmpty(command.Name) || string.IsNullOrWhiteSpace(command.Sex) || string.IsNullOrWhiteSpace(command.DOB))
            //{
            //    throw new ArgumentException("Name, Sex, and DOB are required to update the producer.");
            //}

            var producer = await _ApiDbContext.Producers.FindAsync(id);

            if (producer == null)
            {
                throw new Exception("Producer not found.");
            }

            producer.Name = command.Name;
            producer.Sex = command.Sex;
            producer.DOB = command.DOB;
            producer.Bio = command.Bio;

            _ApiDbContext.Producers.Update(producer);
            await _ApiDbContext.SaveChangesAsync();

            return producer;
        }

        //var producer = await _ApiDbContext.Producers.FindAsync(id);
        //if (producer == null)
        //{
        //    throw new Exception("Producer not found./ Invalid Id.");
        //}

        //producer.Name = command.Name;
        //producer.Sex = command.Sex;
        //producer.DOB = command.DOB;
        //producer.Bio = command.Bio;

        //// Save updated actor
        //_ApiDbContext.Producers.Update(producer);
        //await _ApiDbContext.SaveChangesAsync();

        //return producer;
    }
}

