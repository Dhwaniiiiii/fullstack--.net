﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using TaskWebApplication1.Model;
using TaskWebApplication1.ViewModel;

namespace TaskWebApplication1.Services
{
    public interface IActorService
    {
        Task<ActorResult> AddActor(AddActorCommand command);
        Task<List<Actor>> GetAllActorsAsync();
        Task<ActorResult> GetActorByIdAsync(int id);
        Task DeleteActor(int id);
        Task<Actor> UpdateActor(int id, UpdateActorCommand actor);

        //Task ValidateActor(AddActorCommand command);
    }
}
