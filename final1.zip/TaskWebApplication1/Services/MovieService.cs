﻿
using System.Security.Cryptography;
using Azure;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TaskWebApplication1.Data;
using TaskWebApplication1.Model;
using TaskWebApplication1.ViewModel;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;

namespace TaskWebApplication1.Services
{
    public class MovieService : IMovieService
    {
        private readonly ApiDbContext _ApiDbContext;
        public MovieService(ApiDbContext context)
        {
            _ApiDbContext = context;
        }

        // INSERT
        public async Task<MovieResult> AddMovie(AddMovieCommand command)
        {
            var movie = new Movie()
            {
                Name = command.Name,
                Plot = command.Plot,
                Poster = command.Poster,
                Yor = command.Yor,
                Pid = command.Pid,
                ActorMovies = new List<ActorMovie>()  // Ensure initialization

            };

           
            foreach (var actorId in command.ActorId)
            {
                // Ensure the Actor exists
                var actor = await _ApiDbContext.Actors.FirstOrDefaultAsync(a => a.Aid == actorId);
                if (actor != null)
                {
                    movie.ActorMovies.Add(new ActorMovie() { Aid = actorId, Mid = movie.Mid });
                }
                else
                {
                    throw new Exception($"Actor with ID {actorId} not found.");
                }
            }


            var response = (await _ApiDbContext.Movies.AddAsync(movie)).Entity;
            _ApiDbContext.Movies.Add(movie);
            
            await _ApiDbContext.SaveChangesAsync(); 


            if (response.Mid == null || response.Mid == 0)
            {
                throw new Exception("Movie ID (Mid) is not generated before adding ActorMovie.");
            }

            await _ApiDbContext.SaveChangesAsync();

            if (response != null)
            {
                MovieResult movieResult = new MovieResult()
                {
                    Mid = response.Mid,
                    Name = command.Name,
                    Plot = command.Plot,
                    Poster = command.Poster,
                    Yor = command.Yor, 
                    Pid = command.Pid,
                    Aid = command.ActorId
                };

                return movieResult;
            }

            return null;
        }


        // DISPLAY
        public async Task<IEnumerable<MovieResult>> GetAllMovies()
        {
            try
            {
                var movies = await _ApiDbContext.Movies
                    .Include(m => m.ActorMovies)
                    .ThenInclude(am => am.Actor)
                    .Include(m => m.Producer)
                    .ToListAsync();

                var movieResults = movies.Select(movie => new MovieResult
                {
                    Mid = movie.Mid,
                    Name = movie.Name,
                    Plot = movie.Plot,
                    Poster = movie.Poster,
                    Yor = movie.Yor,
                    Pid = movie.Pid.GetValueOrDefault(),
                    Aid = movie.ActorMovies.Select(am => am.Aid).ToList()
                });

                return movieResults;
            }
            catch (Exception ex)
            {
                throw new Exception($"Can't retrieving movies");
            }
        }


        // ID DATA DISPLAY
        public async Task<MovieResult> GetIdMovies(int id)
        {
           
                var response = await _ApiDbContext.Movies
                    .Include(m => m.ActorMovies)
                    .ThenInclude(am => am.Actor)
                    .Include(m => m.Producer)
                    .FirstOrDefaultAsync(a => a.Mid == id);

                if (response == null)
                {
                    throw new Exception($"Movie with ID {id} not found.");
                }

                MovieResult movieResult = new MovieResult()
                {
                    Mid = response.Mid,
                    Name = response.Name,
                    Plot = response.Plot,
                    Poster = response.Poster,
                    Yor = response.Yor,
                    Pid = response.Pid.GetValueOrDefault(),
                    Aid = response.ActorMovies?.Select(am => am.Aid).ToList() ?? new List<int>()
                };

                return movieResult;
          
        }


        // DELETE
        public async Task DeleteMovie(int id)
        {
            var movie = await _ApiDbContext.Movies
                   .Include(m => m.ActorMovies)  
                   .Include(m => m.Producer)     
                   .FirstOrDefaultAsync(m => m.Mid == id);


            if (movie == null)
            {
                throw new Exception($"Movie with ID {id} not found.");
            }

            _ApiDbContext.ActorMovies.RemoveRange(movie.ActorMovies);
            _ApiDbContext.Movies.Remove(movie);
            await _ApiDbContext.SaveChangesAsync();
        }


        // UPDATE
        public async Task<UpdateMovieResult> UpdateMovie(int id, UpdateMovieCommand command)
        {
            var movie = await _ApiDbContext.Movies
                .Include(m => m.ActorMovies)
                 .Include(m => m.Producer)
                .FirstOrDefaultAsync(m => m.Mid == id);

            if (movie.Mid == null)
            {
                throw new Exception($"Movie with ID {id} not found.");
            }



            movie.Name = command.Name;
            movie.Plot = command.Plot;
            movie.Poster = command.Poster;
            movie.Yor = (int)command.Yor;


            if (command.Pid != 0 && command.Pid != movie.Pid)
            {
                var producer = await _ApiDbContext.Producers
                      .FirstOrDefaultAsync(p => p.Pid == command.Pid);
                if (producer != null)
                {
                    movie.Pid = command.Pid;
                }
                else
                {
                    throw new Exception("Producer not found.");
                }
            }

            if (command.Aid != null && command.Aid.Any())
            {
                movie.ActorMovies.Clear();

                foreach (var actorId in command.Aid)
                {
                    // Ensure the Actor exists
                    var actor = await _ApiDbContext.Actors.FirstOrDefaultAsync(a => a.Aid == actorId);

                    if (actor != null) // Ensure the actor was found
                    {
                        movie.ActorMovies.Add(new ActorMovie() { Aid = actorId, Mid = movie.Mid });
                    }
                    else
                    {
                        throw new Exception($"Actor with ID {actorId} not found.");
                    }
                }
            }


            await _ApiDbContext.SaveChangesAsync();

            return new UpdateMovieResult
            {
                Mid = movie.Mid,
                Name = movie.Name,
                Plot = movie.Plot,
                Poster = movie.Poster,
                Yor = movie.Yor,
                Pid = (int)movie.Pid,
                ActorIds = movie.ActorMovies.Select(am => am.Aid).ToList()
            };
        }
    }
}


//if (string.IsNullOrWhiteSpace(command.Name))
//{
//    throw new Exception("Movie name is required.");
//}

//if (string.IsNullOrWhiteSpace(command.Plot))
//{
//    throw new Exception("Movie plot is required.");
//}

//if (string.IsNullOrWhiteSpace(command.Poster))
//{
//    throw new Exception("Movie poster is required.");
//}

//if (command.Yor <= 0 || command.Yor > DateTime.Now.Year)
//{
//    throw new Exception("Year of release must be a valid year (not in the future).");
//}

//if (command.Pid <= 0)
//{
//    throw new Exception("Producer ID is required.");
//}

//var producer = await _ApiDbContext.Producers
//         .FirstOrDefaultAsync(p => p.Pid == command.Pid);

//if (producer == null)
//{
//    throw new Exception("Producer not found.");
//}

//// Validate required fields
//if (string.IsNullOrWhiteSpace(command.Name))
//{
//    throw new Exception("Movie name is required.");
//}

//if (string.IsNullOrWhiteSpace(command.Plot))
//{
//    throw new Exception("Movie plot is required.");
//}

//if (string.IsNullOrWhiteSpace(command.Poster))
//{
//    throw new Exception("Movie poster is required.");
//}

//if (command.Yor <= 0 || command.Yor > DateTime.Now.Year)
//{
//    throw new Exception("Year of release must be a valid year (not in the future).");
//}

//if (command.Pid != 0 && command.Pid != movie.Pid)
//{
//    var producer = await _ApiDbContext.Producers
//          .FirstOrDefaultAsync(p => p.Pid == command.Pid);
//    if (producer == null)
//    {
//        throw new Exception("Producer not found.");
//    }
//    movie.Pid = command.Pid;
//}