﻿using TaskWebApplication1.Model;
using TaskWebApplication1.ViewModel;

namespace TaskWebApplication1.Services
{
    public interface IProducerService
    {
        Task<ProducerResult> AddProducer(AddProducerCommand command);
        Task<List<Producer>> GetAllProducersAsync();
        Task<Producer> GetProducerByIdAsync(int id);
        Task DeleteProducer(int id);
        Task<Producer> UpdateProducer(int id, UpdateProducerCommand command);
    }
}
