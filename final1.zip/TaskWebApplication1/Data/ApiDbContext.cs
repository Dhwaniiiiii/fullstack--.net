﻿using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using Microsoft.Extensions.Options;
using TaskWebApplication1.Model;

namespace TaskWebApplication1.Data
{
    public class ApiDbContext : DbContext
    {
        public ApiDbContext(DbContextOptions<ApiDbContext> options) : base(options) { }

        public DbSet<Actor> Actors { get; set; }
        public DbSet<Movie> Movies { get; set; }
        public DbSet<Producer> Producers { get; set; }

        public DbSet<ActorMovie> ActorMovies { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Many-to-many relationship between Movies and Actors
            modelBuilder.Entity<ActorMovie>()
           .HasKey(am => new { am.Aid, am.Mid });


            modelBuilder.Entity<ActorMovie>()
            .HasOne(am => am.Movie)
            .WithMany(m => m.ActorMovies)
            .HasForeignKey(am => am.Mid);


            modelBuilder.Entity<ActorMovie>()
                .HasOne(am => am.Actor)
                .WithMany(a => a.ActorMovies)
                .HasForeignKey(am => am.Aid);

            modelBuilder.Entity<Movie>()
               .HasOne(m => m.Producer)
               .WithMany(p => p.Movies)
               .HasForeignKey(m => m.Pid);
        }



        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            //optionsBuilder.UseSqlServer(@"Server=DESKTOP-5HNO3EV;Database=imdb;Trusted_Connection=True;TrustServerCertificate=True;Integrated Security=True;");
        }

        // add-migration name
        //update-database
    }


}
