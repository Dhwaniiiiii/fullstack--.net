﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace TaskWebApplication1.Migrations
{
    /// <inheritdoc />
    public partial class _2 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Movies_Producers_ProducerPid",
                table: "Movies");

            migrationBuilder.DropIndex(
                name: "IX_Movies_ProducerPid",
                table: "Movies");

            migrationBuilder.DropColumn(
                name: "ProducerPid",
                table: "Movies");

            migrationBuilder.AlterColumn<int>(
                name: "Pid",
                table: "Movies",
                type: "int",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.CreateIndex(
                name: "IX_Movies_Pid",
                table: "Movies",
                column: "Pid");

            migrationBuilder.AddForeignKey(
                name: "FK_Movies_Producers_Pid",
                table: "Movies",
                column: "Pid",
                principalTable: "Producers",
                principalColumn: "Pid");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Movies_Producers_Pid",
                table: "Movies");

            migrationBuilder.DropIndex(
                name: "IX_Movies_Pid",
                table: "Movies");

            migrationBuilder.AlterColumn<int>(
                name: "Pid",
                table: "Movies",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AddColumn<int>(
                name: "ProducerPid",
                table: "Movies",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_Movies_ProducerPid",
                table: "Movies",
                column: "ProducerPid");

            migrationBuilder.AddForeignKey(
                name: "FK_Movies_Producers_ProducerPid",
                table: "Movies",
                column: "ProducerPid",
                principalTable: "Producers",
                principalColumn: "Pid",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
