﻿using System.ComponentModel.DataAnnotations;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using TaskWebApplication1.Model;

namespace TaskWebApplication1.Model
{
    public class ActorMovie
    {
        [Key]
        public int Id { get; set; }

        public int Mid { get; set; }
        public int Aid { get; set; }

        public Movie Movie { get; set; } 
        public Actor Actor { get; set; } 
    }

}
