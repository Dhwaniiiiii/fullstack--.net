﻿using System.ComponentModel.DataAnnotations;

namespace TaskWebApplication1.Model
{
    public class Producer
    {
        [Key]
        public int Pid { get; set; }
        public string Name { get; set; }

        [Required(ErrorMessage = "Sex is required")]
        public string Sex { get; set; }

        public string DOB { get; set; }

        [StringLength(500, ErrorMessage = "Bio can't be longer than 500 characters")]
        public string Bio { get; set; }

        public ICollection<Movie>? Movies { get; set; }
    }
}
