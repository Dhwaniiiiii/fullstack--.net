﻿using System.ComponentModel.DataAnnotations;

namespace TaskWebApplication1.Model
{
    public class Actor
    {
        //internal object id;

        [Key]
        public int Aid { get; set; }

        [Required]
        public string Name { get; set; }

        public string Sex { get; set; }
       
        [Display(Name = "Date of Birth")]
        public string DOB { get; set; }

        public string Bio { get; set; }

        public ICollection<ActorMovie>? ActorMovies { get; set; }


    }
}
