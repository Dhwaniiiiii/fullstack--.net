﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TaskWebApplication1.Model
{
    public class Movie
    {
        [Key]
        public int Mid { get; set; }
        public string Name { get; set; }
        public int Yor { get; set; }
        public string Plot { get; set; }
        public string Poster { get; set; }

        public int? Pid { get; set; }
        public Producer? Producer { get; set; }

        public ICollection<ActorMovie> ActorMovies { get; set; }
    }
}
