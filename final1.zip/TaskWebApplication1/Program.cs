using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Builder;
using TaskWebApplication1.Services;
using TaskWebApplication1.Data;
using FluentValidation;
using TaskWebApplication1.ViewModel;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();  // sir

// Learn more about configuring OpenAPI at https://aka.ms/aspnet/openapi
builder.Services.AddOpenApi();


//  Connection String from appsettings.json
builder.Services.AddDbContext<ApiDbContext>(options =>
    options.UseSqlServer("Server=DESKTOP-5HNO3EV;Database=imdb;Trusted_Connection=True;TrustServerCertificate=True;Integrated Security=True;"));



// Register Service
builder.Services.AddScoped<IMovieService, MovieService>();
builder.Services.AddScoped<IActorService, ActorService>();
builder.Services.AddScoped<IProducerService,ProducerService>();



// Validator 
builder.Services.AddScoped<IValidator<AddActorCommand>, AddActorCommandValidator>();
builder.Services.AddScoped<IValidator<UpdateActorCommand>, UpdateActorCommandValidator>();
builder.Services.AddScoped<IValidator<AddMovieCommand>, AddMovieCommandValidator>();
builder.Services.AddScoped<IValidator<UpdateMovieCommand>, UpdateMovieCommandValidator>();
builder.Services.AddScoped<IValidator<AddProducerCommand>, AddProducerCommandValidator>();
builder.Services.AddScoped<IValidator<UpdateProducerCommand>, UpdateProducerCommandValidator>();




// JSON Options
builder.Services.AddControllers()
    .AddJsonOptions(options =>
    {
        options.JsonSerializerOptions.ReferenceHandler = System.Text.Json.Serialization.ReferenceHandler.Preserve;
    });



var app = builder.Build();

// Swagger Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseDeveloperExceptionPage();
    app.UseSwagger();
    app.UseSwaggerUI();
    app.MapOpenApi();
}
else
{
    app.UseExceptionHandler("/Home/Error");  // Generic error handling for production
    app.UseHsts();  // HTTP Strict Transport Security in production
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
