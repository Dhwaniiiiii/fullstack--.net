﻿using System.ComponentModel.DataAnnotations;
using FluentValidation;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TaskWebApplication1.Data;
using TaskWebApplication1.Model;
using TaskWebApplication1.Services;
using TaskWebApplication1.ViewModel;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace TaskWebApplication1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProducersController : ControllerBase
    {
        private readonly ApiDbContext _dbContext;
        private readonly IProducerService _producerService;
        public ProducersController(ApiDbContext context, IProducerService producerService)
        {
            _dbContext = context;
            _producerService = producerService;
        }



        // GET: api/<ProducersController>
        [HttpGet("AllDetail")]
        public async Task<IActionResult> GetProducers()
        {
            var producers = await _producerService.GetAllProducersAsync();
            if (producers == null || producers.Count == 0)
            {
                return NotFound(new { message = "No Producer found." });
            }
            return Ok(producers);
        }



        // GET api/<ProducersController>/5
        [HttpGet("SpecificProducerIdDetail")]
        public async Task<ActionResult<Producer>> GetProducersById(int Pid)
        {
            try
            {
                var producerResult = await _producerService.GetProducerByIdAsync(Pid);
                return Ok(producerResult); 
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }



        [HttpPost]
        public async Task<ActionResult<ProducerResult>> PostProducer([FromBody] AddProducerCommand command, [FromServices] IValidator<AddProducerCommand> validator)
        {
            var validationResult = await validator.ValidateAsync(command);
            if (!validationResult.IsValid)
            {
                return BadRequest(validationResult.Errors.Select(e => e.ErrorMessage));
            }
            var producerResult = await _producerService.AddProducer(command);
            return Ok(producerResult);
        }
            //try
            //{
            //    var producerResult = await _producerService.AddProducer(command);
            //    return CreatedAtAction(nameof(GetProducersById), new { Pid = producerResult.Pid }, producerResult);
            //}
            //catch (ArgumentException ex)
            //{
            //    return BadRequest(ex.Message); 
            //}
            //catch (Exception ex)
            //{
            //    return StatusCode(500, new { message = ex.Message }); 
            //}
        




        //// PUT api/<ProducersController>/5
        //[HttpPut("{id}")]
        //public IActionResult Put(int id, [FromBody] Producer producer)
        //{
        //    var pr = _dbContext.Producers.Find(id);
        //    if (pr == null)
        //    {
        //        return NotFound();
        //    }
        //    pr.Name = producer.Name;
        //    pr.Sex = producer.Sex;
        //    pr.DOB = producer.DOB;
        //    pr.Bio = producer.Bio;
        //    _dbContext.SaveChanges();
        //    return NoContent();
        //}




        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateProducer(int id, [FromBody] UpdateProducerCommand command, [FromServices] IValidator<UpdateProducerCommand> validator)
        {
            var existingActor = await _producerService.GetProducerByIdAsync(id);
            if (existingActor == null)
            {
                return NotFound($"Producer with ID {id} not found.");
            }

            var validationResult = await validator.ValidateAsync(command);
            if (!validationResult.IsValid)
            {
                return BadRequest(validationResult.Errors.Select(e => e.ErrorMessage));
            }
        
            var updatedActor = await _producerService.UpdateProducer(id, command);
            return Ok(updatedActor);
        }




        // DELETE api/<ProducersController>/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteProducer(int id)
        {
            try
            {
                await _producerService.DeleteProducer(id);

                return Ok(new { message = $"Producer with ID {id} has been deleted successfully." });
            }
            catch (Exception ex)
            {
                return NotFound();
            }
        }
    }
}
