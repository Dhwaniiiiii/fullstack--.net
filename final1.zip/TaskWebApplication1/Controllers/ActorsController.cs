﻿using System.ComponentModel.DataAnnotations;
using System.Security.Claims;
using Azure.Core;
using FluentValidation;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TaskWebApplication1.Data;
using TaskWebApplication1.Model;
using TaskWebApplication1.Services;
using TaskWebApplication1.ViewModel;
using static System.Runtime.InteropServices.JavaScript.JSType;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace TaskWebApplication1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ActorsController : ControllerBase
    {
        private readonly ApiDbContext _dbContext;
        private readonly IActorService _actorService;

        public ActorsController(ApiDbContext context, IActorService actorService)
        {
            _dbContext = context;
            _actorService = actorService;
        }



        // GET: api/<ActorsController>
        [HttpGet("AllDetail")]
        public async Task<IActionResult> GetActors()
        {
            var actors = await _actorService.GetAllActorsAsync();
            if (actors == null || actors.Count == 0)
            {
                return NotFound(new { message = "there's no actors record." });
            }
            return Ok(actors); 
        }



        // GET api/<MoviesController>/5
        [HttpGet("SpecificActorIdDetail")]
        public async Task<ActionResult<Actor>> GetActors(int Aid)
        {
            try
            {
                var actorResult = await _actorService.GetActorByIdAsync(Aid);
                return Ok(actorResult); // Return the actor details if found
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }


       
        // POST api/<ActorsController>
        [HttpPost]
        public async Task<ActionResult<ActorResult>> PostActor([FromBody] AddActorCommand command, [FromServices] IValidator<AddActorCommand> validator)
        {
            var validationResult = await validator.ValidateAsync(command);
            if (!validationResult.IsValid)
            {
                return BadRequest(validationResult.Errors.Select(e => e.ErrorMessage));
            }
            var actorResult = await _actorService.AddActor(command);
            return Ok(actorResult);               
        }




        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateActor(int id, [FromBody] UpdateActorCommand actor, [FromServices] IValidator<UpdateActorCommand> validator)
        {
            try
            {
                var existingActor = await _actorService.GetActorByIdAsync(id);
                if (existingActor == null)
                {
                    return NotFound($"Actor with ID {id} not found.");
                }

                var validationResult = await validator.ValidateAsync(actor);
                if (!validationResult.IsValid)
                {
                    return BadRequest(validationResult.Errors.Select(e => e.ErrorMessage));
                }
  
                var updatedActor = await _actorService.UpdateActor(id, actor);

                return Ok(updatedActor);
            }
            catch (Exception ex)
            {
                if (ex.Message.Contains("Actor with ID"))
                {
                    return NotFound(ex.Message);  // Return the same not found message
                }
                return BadRequest(ex.Message);  // For other exceptions
            }
        }



        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteMovie(int id)
        {
            try
            {
                await _actorService.DeleteActor(id);                    
                return Ok(new { message = $"Actor with ID {id} has been deleted successfully." });
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
            
        }
    }
}
