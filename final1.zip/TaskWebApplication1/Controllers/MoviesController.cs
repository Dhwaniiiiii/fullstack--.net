﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using TaskWebApplication1.Data;
using TaskWebApplication1.Model;
using System.Linq;
using TaskWebApplication1.ViewModel;
using TaskWebApplication1.Services;
using FluentValidation;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace TaskWebApplication1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MoviesController : ControllerBase
    {
        private readonly ApiDbContext _dbContext;
        private readonly IMovieService _movieService;
        private readonly IValidator<AddMovieCommand> _addMovieValidator;
        private readonly IValidator<UpdateMovieCommand> _updateMovieValidator;



        public MoviesController(ApiDbContext context, IMovieService movieService,
                                IValidator<AddMovieCommand> addMovieValidator,
                                IValidator<UpdateMovieCommand> updateMovieValidator)
        {
            _dbContext = context;
            _movieService = movieService;
            _addMovieValidator = addMovieValidator;
            _updateMovieValidator = updateMovieValidator;
        }


        [HttpPost]
        public async Task<ActionResult<MovieResult>> PostMovie([FromBody] AddMovieCommand command)
        {
            var validationResult = await _addMovieValidator.ValidateAsync(command);
            if (!validationResult.IsValid)
            {
                var errorMessages = validationResult.Errors.Select(e => e.ErrorMessage).ToList();

                return BadRequest(errorMessages);
            }
            try
            {
                var result = await _movieService.AddMovie(command);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }

        }



        [HttpGet("ShowAllMovieDetail")]
        public async Task<IActionResult> GetAllMovies()
        {
            var movieResults = await _movieService.GetAllMovies();
            return Ok(movieResults);
        }



        [HttpGet("SpecificMovieIdDetail")]
        public async Task<ActionResult<MovieResult>> GetMovieById(int id)
        {
            try
            {
                var movie = await _movieService.GetIdMovies(id);
                return Ok(movie);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }



        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteMovie(int id)
        {
            try
            {
                await _movieService.DeleteMovie(id);
                return Ok($"Movie with ID {id} has been deleted successfully.");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }



        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateMovie(int id, [FromBody] UpdateMovieCommand request)
        {
            var movieExists = await _dbContext.Movies.AnyAsync(m => m.Mid == id);
            if (!movieExists)
            {
                return NotFound($"Movie with ID {id} not found.");
            }
            try
            {
                var validationResult = await _updateMovieValidator.ValidateAsync(request);
                if (!validationResult.IsValid)
                {
                    var errorMessages = validationResult.Errors.Select(e => e.ErrorMessage).ToList();
                    return BadRequest(errorMessages);
                }

                var updatedMovie = await _movieService.UpdateMovie(id, request);
                return Ok(updatedMovie);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

    }
}



