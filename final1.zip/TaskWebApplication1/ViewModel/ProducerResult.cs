﻿using System.ComponentModel.DataAnnotations;

namespace TaskWebApplication1.ViewModel
{
    public class ProducerResult
    {
        public int Pid { get; set; }
        public string Name { get; set; }
        public string Sex { get; set; }
        public string DOB { get; set; }
        public string Bio { get; set; }
    }
}
