﻿using System.ComponentModel.DataAnnotations;

namespace TaskWebApplication1.ViewModel
{
    public class AddMovieCommand
    {
        //[Required]
        public string Name { get; set; }
        public int Yor { get; set; }
        public string Plot { get; set; }
        public string Poster { get; set; }

        //[Required(ErrorMessage = "Producer ID (Pid) is required.")]
        public int Pid { get; set; }

        //[Required(ErrorMessage = "At least one actor ID is required.")]
        public List<int> ActorId { get; set; } 

    }
}

