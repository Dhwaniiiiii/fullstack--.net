﻿using FluentValidation;

namespace TaskWebApplication1.ViewModel
{
    public class UpdateMovieCommandValidator : AbstractValidator<UpdateMovieCommand>
    {
        public UpdateMovieCommandValidator()
        {
            //RuleFor(a => a.Mid)
            //.GreaterThan(0).WithMessage("Movie ID must be a valid number.");

            RuleFor(m => m.Name)
                .NotEmpty().WithMessage("Movie name is required.");

            RuleFor(m => m.Plot)
                .NotEmpty().WithMessage("Movie plot is required.");

            RuleFor(m => m.Poster)
                .NotEmpty().WithMessage("Movie poster is required.");

            RuleFor(m => m.Yor)
                .GreaterThan(0).WithMessage("Year of release must be a valid year.")
                .LessThanOrEqualTo(DateTime.Now.Year).WithMessage("Year of release cannot be in the future.");

            RuleFor(m => m.Pid)
                .GreaterThan(0).WithMessage("Producer ID is required.");

            RuleFor(m => m.Aid)
                .NotEmpty().WithMessage("At least one actor ID is required.");
        }
    }
}
