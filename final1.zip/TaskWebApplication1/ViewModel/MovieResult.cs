﻿namespace TaskWebApplication1.ViewModel
{
    public class MovieResult
    {
        public int Mid { get; set; }
        public string Name { get; set; }
        public int Yor { get; set; }
        public string Plot { get; set; }
        public string Poster { get; set; }

        public int Pid { get; set; }

        public List<int> Aid { get; set; }



    }
}
