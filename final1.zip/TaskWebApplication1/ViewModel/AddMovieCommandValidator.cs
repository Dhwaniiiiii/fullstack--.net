﻿using FluentValidation;

namespace TaskWebApplication1.ViewModel
{
    public class AddMovieCommandValidator : AbstractValidator<AddMovieCommand>
    {
        public AddMovieCommandValidator()
        {
            RuleFor(m => m.Name)
                .NotEmpty().WithMessage("Movie name is required.");

            RuleFor(m => m.Plot)
                .NotEmpty().WithMessage("Movie plot is required.");

            RuleFor(m => m.Poster)
                .NotEmpty().WithMessage("Movie poster is required.");

            RuleFor(m => m.Yor)
                .NotEmpty().GreaterThan(0).WithMessage("Year of release must be a valid year.")
                .LessThanOrEqualTo(DateTime.Now.Year).WithMessage("Year of release cannot be in the future.");

            RuleFor(m => m.Pid)
                .NotEmpty().GreaterThan(0).WithMessage("Producer ID is required.");

            RuleFor(m => m.ActorId)
                .NotEmpty().WithMessage("At least one actor ID is required.");
        }
    }
}
