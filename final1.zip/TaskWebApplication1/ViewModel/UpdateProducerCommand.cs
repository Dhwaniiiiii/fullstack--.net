﻿using System.ComponentModel.DataAnnotations;
using System.Globalization;

namespace TaskWebApplication1.ViewModel
{
    public class UpdateProducerCommand
    {
        public int Pid { get; set; }

        //[Required(ErrorMessage = "Producer Name is required.")]
        public string Name { get; set; }

        //[Required(ErrorMessage = "Sex is required.")]
        //[StringLength(6, ErrorMessage = "Sex must be 'male', 'female' or 'other'.")]
        public string Sex { get; set; }


        //[Required(ErrorMessage = "Date of Birth (DOB) is required.")]
        //[DateFormat("dd/MM/yyyy", ErrorMessage = "Date of Birth (DOB) must be in dd/MM/yyyy format.")]
        public string DOB { get; set; }


        //[StringLength(500, ErrorMessage = "Bio cannot be longer than 500 characters.")]
        public string Bio { get; set; }
    }

    //public class DateFormatAttribute : ValidationAttribute
    //{
    //    private readonly string _dateFormat;
    //    public DateFormatAttribute(string dateFormat)
    //    {
    //        _dateFormat = dateFormat;
    //    }

    //    public override bool IsValid(object value)
    //    {
    //        if (value == null) return false;

    //        // Try to parse the date in the provided format
    //        return DateTime.TryParseExact(value.ToString(), _dateFormat, CultureInfo.InvariantCulture, DateTimeStyles.None, out _);
    //    }

    //    public override string FormatErrorMessage(string name)
    //    {
    //        return $"The {name} field must be in the format {_dateFormat}.";
    //    }
    //}
}
