﻿using FluentValidation;

namespace TaskWebApplication1.ViewModel
{
    public class AddProducerCommandValidator : AbstractValidator<AddProducerCommand>
    {
        public AddProducerCommandValidator()
        {
            RuleFor(x => x.Name)
               .NotEmpty().WithMessage("Producr name is required")
               .MaximumLength(100).WithMessage("Producr name cannot exceed 100 characters");

            RuleFor(x => x.Sex)
                .NotEmpty().WithMessage("Sex is required")
                .Matches(@"^(male|female|other)$").WithMessage("Sex must be 'male', 'female', or 'other'");
         
            RuleFor(x => x.DOB)
               .NotEmpty().WithMessage("Date of Birth is required")
               .Matches(@"^\d{2}/\d{2}/\d{4}$").WithMessage("DOB must be in DD/MM/YYYY format")
               .Must(BeAValidDate).WithMessage("Invalid Date of Birth. Ensure it is a valid date.")
               .Must(BeAReasonableDate).WithMessage("DOB cannot be in the future or too far in the past");

            RuleFor(x => x.Bio)
                .MaximumLength(10).WithMessage("Bio can't exceed 100 characters");
        }

        private bool BeAValidDate(string dob)
        {
            DateTime date;
            // DD/MM/YYYY format
            return DateTime.TryParseExact(dob, "dd/MM/yyyy", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out date);
        }

        private bool BeAReasonableDate(string dob)
        {
            DateTime date;
            if (!DateTime.TryParseExact(dob, "dd/MM/yyyy", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out date))
            {
                return false;
            }     
            var maxAge = DateTime.Now.AddYears(-100); 
            return date <= DateTime.Now && date >= maxAge;
        }

    }
}

