﻿using FluentValidation;

namespace TaskWebApplication1.ViewModel
{
    public class UpdateActorCommandValidator : AbstractValidator <UpdateActorCommand>
    {
        public UpdateActorCommandValidator()
        {
            //RuleFor(a => a.Aid)
            //.GreaterThan(0).WithMessage("Actor ID must be a valid number.");

            RuleFor(x => x.Name)
                .NotEmpty().WithMessage("Actor name is required")
                .MaximumLength(100).WithMessage("Actor name cannot exceed 100 characters");

            RuleFor(x => x.Sex)
                .NotEmpty().WithMessage("Sex is required")
                .Matches(@"^(male|female|other)$").WithMessage("Sex must be 'male', 'female', or 'other'");

            RuleFor(x => x.DOB)
                .NotEmpty().WithMessage("Date of Birth is required")
                .Matches(@"^(0[1-9]|[12][0-9]|3[01])/(0[1-9]|1[0-2])/\d{4}$")
                .WithMessage("Invalid Date of Birth format. Use dd/MM/yyyy.")
                .Must(BeAValidDate).WithMessage("Invalid Date of Birth. Date doesn't exist or is invalid.")
                .Must(BeNotInFuture).WithMessage("Date of Birth cannot be a future date.");

            RuleFor(x => x.Bio)
                .MaximumLength(100).WithMessage("Bio can't exceed 100 characters");
        }

        private bool BeAValidDate(string dob)
        {
            DateTime date;
            return DateTime.TryParseExact(dob, "dd/MM/yyyy",
                System.Globalization.CultureInfo.InvariantCulture,
                System.Globalization.DateTimeStyles.None, out date);
        }

        private bool BeNotInFuture(string dob)
        {
            DateTime date;
            return DateTime.TryParseExact(dob, "dd/MM/yyyy",
                System.Globalization.CultureInfo.InvariantCulture,
                System.Globalization.DateTimeStyles.None, out date)
                && date <= DateTime.Now;
        }
    }
}

