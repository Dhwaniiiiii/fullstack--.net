﻿using System.ComponentModel.DataAnnotations;

namespace TaskWebApplication1.ViewModel
{
    public class AddActorCommand
    {
        [Required]
        public string Name { get; set; }

       // [RegularExpression(@"^(male|female|other)$", ErrorMessage = "Sex must be either 'male', 'female', or 'other'.")]
        public string Sex { get; set; }

       // [Required(ErrorMessage = "Date of Birth is required.")]
        public string DOB { get; set; }

        //[StringLength(10, ErrorMessage = "Bio can't exceed 10 characters.")]
        public string Bio { get; set; }
    }
}
