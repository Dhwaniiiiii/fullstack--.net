﻿using FluentValidation;

namespace TaskWebApplication1.ViewModel
{
    public class AddActorCommandValidator : AbstractValidator<AddActorCommand>
    {

        public AddActorCommandValidator()
        {
            RuleFor(x => x.Name)
               .NotEmpty().WithMessage("Actor name is required")
               .MaximumLength(100).WithMessage("Actor name cannot exceed 100 characters");

            RuleFor(x => x.Sex)
                .NotEmpty().WithMessage("Sex is required")
                .Matches(@"^(male|female|other)$").WithMessage("Sex must be 'male', 'female', or 'other'");

            //RuleFor(x => x.DOB)
            //    .NotEmpty().WithMessage("Date of Birth is required")
            //    .Matches(@"^\d{2}/\d{2}/\d{4}$").WithMessage("DOB must be in DD/MM/YYYY format");

            RuleFor(x => x.DOB)
               .NotEmpty().WithMessage("Date of Birth is required")
               .Matches(@"^\d{2}/\d{2}/\d{4}$").WithMessage("DOB must be in DD/MM/YYYY format")
               .Must(BeAValidDate).WithMessage("Invalid Date of Birth. Ensure it is a valid date.")
               .Must(BeAReasonableDate).WithMessage("DOB cannot be in the future or too far in the past");

            RuleFor(x => x.Bio)
                .MaximumLength(10).WithMessage("Bio can't exceed 100 characters");
        }

        //private bool BeAValidDate(string dob)
        //{
        //    DateTime date;
        //    bool isValidDate = DateTime.TryParseExact(dob, "dd/MM/yyyy",
        //        System.Globalization.CultureInfo.InvariantCulture,
        //        System.Globalization.DateTimeStyles.None, out date);

        //    if (!isValidDate)
        //    {
        //        return false; // Invalid date format or invalid date
        //    }

        //    // Ensure the date is not in the future
        //    return date <= DateTime.Now; // Date must be in the past or today
        //}

        private bool BeAValidDate(string dob)
        {
            DateTime date;
            // Attempt to parse the date from the input in DD/MM/YYYY format
            return DateTime.TryParseExact(dob, "dd/MM/yyyy", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out date);
        }

        private bool BeAReasonableDate(string dob)
        {
            DateTime date;
            if (!DateTime.TryParseExact(dob, "dd/MM/yyyy", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out date))
            {
                return false;
            }

            // Check if the date is in the future or too far in the past (e.g., more than 100 years ago)
            var maxAge = DateTime.Now.AddYears(-100); // Assuming 100 years is the max reasonable age
            return date <= DateTime.Now && date >= maxAge;
        }

    }
}
