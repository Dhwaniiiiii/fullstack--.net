﻿using FluentValidation;

namespace TaskWebApplication1.ViewModel
{
    public class UpdateProducerCommandValidator : AbstractValidator<UpdateProducerCommand>
    {
        public UpdateProducerCommandValidator()
        {
            //RuleFor(a => a.Pid)
            //.GreaterThan(0).WithMessage("Producer ID must be a valid number.");

            // Validate Name
            RuleFor(x => x.Name)
                .NotEmpty().WithMessage("Producer name is required")
                .MaximumLength(100).WithMessage("Actor name cannot exceed 100 characters");

            // Validate Sex
            RuleFor(x => x.Sex)
                .NotEmpty().WithMessage("Sex is required")
                .Matches(@"^(male|female|other)$").WithMessage("Sex must be 'male', 'female', or 'other'");

            // Validate DOB (Date of Birth)
            RuleFor(x => x.DOB)
                .NotEmpty().WithMessage("Date of Birth is required")
                .Matches(@"^(0[1-9]|[12][0-9]|3[01])/(0[1-9]|1[0-2])/\d{4}$")
                .WithMessage("Invalid Date of Birth format. Use dd/MM/yyyy.")
                .Must(BeAValidDate).WithMessage("Invalid Date of Birth. Date doesn't exist or is invalid.")
                .Must(BeNotInFuture).WithMessage("Date of Birth cannot be a future date.");

            // Validate Bio
            RuleFor(x => x.Bio)
                .MaximumLength(100).WithMessage("Bio can't exceed 100 characters");
        }

        private bool BeAValidDate(string dob)
        {
            DateTime date;
            // Validate if the date is valid (correct day/month/year combination)
            return DateTime.TryParseExact(dob, "dd/MM/yyyy",
                System.Globalization.CultureInfo.InvariantCulture,
                System.Globalization.DateTimeStyles.None, out date);
        }

        private bool BeNotInFuture(string dob)
        {
            DateTime date;
            // Ensure the date is not in the future
            return DateTime.TryParseExact(dob, "dd/MM/yyyy",
                System.Globalization.CultureInfo.InvariantCulture,
                System.Globalization.DateTimeStyles.None, out date)
                && date <= DateTime.Now;
        }
    }
}
