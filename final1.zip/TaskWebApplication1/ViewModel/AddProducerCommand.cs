﻿using System.ComponentModel.DataAnnotations;

namespace TaskWebApplication1.ViewModel
{
    public class AddProducerCommand
    {
        //[Required(ErrorMessage = "Producer Name is required.")]
        public string Name { get; set; }

        //[Required(ErrorMessage = "Sex is required.")]
        //[StringLength(6, ErrorMessage = "Sex must be 'male', 'female' or 'other'.")]
        public string Sex { get; set; }

        //[Required(ErrorMessage = "Date of Birth is required.")]
        public string DOB { get; set; }

        //[StringLength(500, ErrorMessage = "Bio cannot exceed 500 characters.")]
        public string Bio { get; set; }
    }
}
